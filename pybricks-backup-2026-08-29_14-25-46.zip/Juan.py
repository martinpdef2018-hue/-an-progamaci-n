from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

motorderecha = Motor (Port E, Direction CLOCKWISE)
motorizquierda = Motor (Port D, Direction COUNTERCLOCKWISE)

motorderecha


